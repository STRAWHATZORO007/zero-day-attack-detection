
Research Contributions
----------------------
- Hybrid ensemble anomaly scoring (deep + statistical)
- Zero-day evaluation methodology
- Adaptive IDS architecture

This system is intentionally designed to be extendable
into MSc thesis work (federated IDS, adversarial ML).
