
import pandas as pd
import torch
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
from models import BehavioralAutoencoder

df = pd.read_csv("data/train.csv")
df['label'] = df['label'].str.lower()

X = df[df['label'] == 'normal'].drop(columns=['label'])
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

torch.save(scaler, "scaler.pt")

model = BehavioralAutoencoder(X_scaled.shape[1])
opt = torch.optim.Adam(model.parameters(), lr=1e-3)
loss_fn = torch.nn.MSELoss()

X_tensor = torch.tensor(X_scaled, dtype=torch.float32)

for _ in range(40):
    opt.zero_grad()
    loss = loss_fn(model(X_tensor), X_tensor)
    loss.backward()
    opt.step()

torch.save(model.state_dict(), "autoencoder.pt")

iso = IsolationForest(contamination=0.02)
iso.fit(X_scaled)
joblib.dump(iso, "isoforest.joblib")

print("Training complete")
