
import pandas as pd
import torch
import joblib
import numpy as np
from models import BehavioralAutoencoder

df = pd.read_csv("data/test.csv")
labels = df['label'].str.lower()
X = df.drop(columns=['label'])

scaler = torch.load("scaler.pt")
X_scaled = scaler.transform(X)

model = BehavioralAutoencoder(X_scaled.shape[1])
model.load_state_dict(torch.load("autoencoder.pt"))
model.eval()

with torch.no_grad():
    recon = model(torch.tensor(X_scaled, dtype=torch.float32))
mse = ((recon - torch.tensor(X_scaled, dtype=torch.float32))**2).mean(dim=1).numpy()

iso = joblib.load("isoforest.joblib")
iso_score = -iso.score_samples(X_scaled)

ensemble_score = 0.7*mse + 0.3*iso_score
threshold = np.percentile(ensemble_score[labels=='normal'], 95)

pred = ensemble_score > threshold

print("Detected anomalies:", pred.sum())
